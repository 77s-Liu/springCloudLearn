package com.springboot.learn.blogs_viewer.services;

import com.springboot.learn.blogs_viewer.entity.User;

public interface RegisterService {
    public String register(User user);
}
