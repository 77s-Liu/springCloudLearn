package com.springboot.learn.blogs_viewer.services;

public interface LoginService {
    public String login(String username,String password);
}
